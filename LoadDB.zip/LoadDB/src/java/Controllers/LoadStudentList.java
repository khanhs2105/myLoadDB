package Controllers;

import DAL.DAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LoadStudentList extends HttpServlet {
    DAO dao;

    @Override
    public void init() {
        dao = new DAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        dao.LoadStd();
        dao.LoadDept();
        request.setAttribute("dao", dao);
        request.getRequestDispatcher("Views/StudentList.jsp").forward(request, response);
    }
}
