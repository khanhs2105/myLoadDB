/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controllers;

import DAL.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


public class FilterStudent extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
            
        Object o1 = request.getParameter("type");
        Object o2 = request.getParameter("id");
       
        if (o1 != null) {
            if ((o1 + "").equals("0")) {
                if (o2 != null) {
                    request.setAttribute("update", o2 + "");
                }
                //update

            } else if ((o1 + "").equals("1")) {
                if (o2 != null) 
                try {
                    int id = Integer.parseInt(o2 + "");
                    DAO.Ins.Delete(id);
                } catch (Exception e) {

                }
            }
        }
    
        DAO.Ins.LoadStd();
        DAO.Ins.LoadDept();
        if(request.getAttribute("FDeptId")==null)
            request.setAttribute("FDeptId", "All");
        
        request.setAttribute("dao", DAO.Ins);
        request.getRequestDispatcher("Views/FilterStudent.jsp").forward(request, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getParameter("btnFilter")!=null){
        //day la click vao filter
            String id = req.getParameter("sltDept");
            req.setAttribute("FDeptId", id);
//            DAO.Ins.Filter(id);
//            req.setAttribute("dao", DAO.Ins);
            doGet(req, resp);
            }
        else{
            
        }
    }
    
}
