package DAL;

import Models.*;
import java.sql.*;
import java.util.Vector;

public class DAO {

    private String status = "ok";
    private Connection con;
    private Vector<Student> std;
    private Vector<Department> dept;
    
    public static final DAO Ins = new DAO();

    public DAO() {
        try {
            con = new DBContext().getConnection();
        } catch (Exception e) {
            status = "Error at connecttion" + e.getMessage();
        }
    }

    public String getStatus() {
        return status;
    }

    public Vector<Student> getStd() {
        return std;
    }

    public Vector<Department> getDept() {
        return dept;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setStd(Vector<Student> std) {
        this.std = std;
    }

    public void setDept(Vector<Department> dept) {
        this.dept = dept;
    }

    public void LoadStd() {
        String sql = "select * from Student";
        std = new Vector<>();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Student st = new Student();
                st.setId(rs.getInt("id"));
                st.setName(rs.getString("name"));
                st.setGender(rs.getBoolean("gender"));
                st.setDepartId(rs.getString("departId"));
                st.setGpa(rs.getFloat("gpa"));
                st.setDob(rs.getDate(5));
                std.add(st);

            }

        } catch (Exception e) {
            status = "Error at read Student" + e.getMessage();
        }
    }

    public void LoadDept() {
        String sql = "select * from Department";
        dept = new Vector<>();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                dept.add(new Department(rs.getString(1), rs.getString(2)));

            }
        } catch (Exception e) {
            status = "Error at read Department" + e.getMessage();
        }
    }

    public String GEtDeptName(String id) {
        for (Department de : dept) {
            if (de.getId().equals(id)) {
                return de.getName();
            }
        }
        return null;
    }

    public void Insert(int id, String name, boolean gender, String dept, String dob, float gpa) {
        String sql = "Insert into student values(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(4, dept);
            ps.setString(5, dob);
            ps.setBoolean(3, gender);
            ps.setFloat(6, gpa);
            ps.execute();
        } catch (Exception e) {
            status = "Error at Insert Student " + e.getMessage();
        }
    }

    public void Update(int id, String name, boolean gender, String deptId, String dob, float gpa) {
        String sql = "Update student set gpa=?,name=?,gender=?," + "departId = ?, dob =? Where id = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(6, id);
            ps.setString(2, name);
            ps.setString(4, deptId);
            ps.setString(5, dob);
            ps.setBoolean(3, gender);
            ps.setFloat(1, gpa);
            ps.execute();
        } catch (Exception e) {
            status = "Error at Insert Student " + e.getMessage();
        }
    }

    public void Delete(int id) {
        String sql = "delete from Student where id = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
            status = "Error at delete Student " + e.getMessage();

        }
    }

    public void Filter(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
